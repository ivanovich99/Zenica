//
//  ContentView.swift
//  CToolBar
//
//  Created by CETYS Universidad  on 11/10/23.
//

import SwiftUI

struct ContentView: View {
    // Variable que guardara donde se encuentra e inicia en house
    @State private var selectedTab: Tab = .house
    
    // Inicializador porque llamaremos el tabbar
    init(){
        UITabBar.appearance().isHidden = true
    }
    
    var body: some View {
        ZStack{
            VStack{
                TabView(selection: $selectedTab){
                    
                    ForEach(Tab.allCases, id: \.rawValue){ tab in
                        // Lo que se mostrara dependiendo el tab
                        HStack{
                            Image(systemName: tab.rawValue)
                            Text("\(tab.rawValue.capitalized)")
                                .bold()
                        }
                        .font(.system(size:40))
                        .tag(tab)
                    }
                    // Si se quiere navegar por varios views usar esta estructura control
                    /*switch selectedTab {
                        case .house:
                            ContentView1()
                        case .magnifyingglassCircle:
                            ContentView2()
                        case .plus:
                            ContentView3()
                        case .person:
                            ContentView4()
                    } */
                }
            }
            VStack{
                // Empuja al fondo el toolbar
                Spacer()
                
                // Se llama el archivo de swift con ayuda de la varibale que los enlaza
                CustomTabBar(selectedTab: $selectedTab)
            }
        }
        
    }
}

#Preview {
    ContentView()
}
