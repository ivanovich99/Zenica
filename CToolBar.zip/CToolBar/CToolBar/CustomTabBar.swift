//
//  CustomTabBar.swift
//  CToolBar
//
//  Created by CETYS Universidad  on 11/10/23.
//

import SwiftUI


// Para poder colores RGB
extension Color {
    init(red: Double, green: Double, blue: Double) {
        self.init(
            .sRGB,
            red: red / 255,
            green: green / 255,
            blue: blue / 255,
            opacity: 1.0
        )
    }
}

// Enmerador striing por los nombres e iterador para ciclar con el
enum Tab: String, CaseIterable{
    // Tabs en toolbar que utilizaremos
    case house
    case magnifyingglass
    case plus
    case person
}

// Funcion para el sombreado, porque la de glass y plus no tienen .fill
func iconName(for tab: Tab) -> String {
    switch tab {
    case .house:
        return "house.circle.fill"
    case .magnifyingglass:
        return "magnifyingglass.circle.fill"
    case .plus:
        return "plus.circle.fill"
    case .person:
        return "person.circle.fill"
    }
}


struct CustomTabBar: View {
    // Variable para poder tener en cuenta tab donde estemos
    @Binding var selectedTab:Tab
    
    // Variable para cuando este en tab se rellene
    private var fillImage : String{
        selectedTab.rawValue + ".fill"
    }
    
    
    var body: some View {
        VStack {
            // El Toolbar principal
            HStack{
                // Ciclo donde desplegara todos los tabs, con id para verificar si esta llena o no
                ForEach(Tab.allCases, id: \.rawValue){ tab in
                    // Formato de como se desplegaran
                    Spacer()
                    // Puros If para verificar si esta seleccionado o no
                    // Y systemName en base a los simbolos
                    Image(systemName: selectedTab == tab ? iconName(for: tab) : tab.rawValue)
                        // Si seleccionado, un poco mas grande que los otros y asi destaca
                        .scaleEffect(selectedTab == tab ? 2 : 1.0)
                        .foregroundColor(selectedTab == tab ? Color(red: 13, green: 40, blue: 24) : Color(red: 38, green: 196, blue: 133)) // Depende si seleccionado cambia color
                        .font(.system(size:25)) // Tamañito iconos
                        .onTapGesture{ // Animacion al momento de tocar
                            withAnimation(.easeIn(duration: 0.1)){
                                selectedTab = tab
                            }
                        }
                    Spacer()
                }
            }
            // Nil para todo el espacio disponible
            .frame(width: nil, height: 80)
            .background(.thinMaterial) // Color de fondo
            //.cornerRadius(15)
        }
        //.padding() Quitar para que se vyaa todo hasta abajo
    }
}

#Preview {
    CustomTabBar(selectedTab: .constant(.house))
}
