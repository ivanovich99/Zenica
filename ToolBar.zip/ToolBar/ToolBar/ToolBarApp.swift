//
//  ToolBarApp.swift
//  ToolBar
//
//  Created by CETYS Universidad  on 10/10/23.
//

import SwiftUI

@main
struct ToolBarApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView(selectedTab: .constant(.plus))
        }
    }
}
