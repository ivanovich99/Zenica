//
//  FetucciniView.swift
//  Bonsai p1
//
//  Created by CETYS Universidad  on 10/10/23.
//

import SwiftUI

struct FetucciniView: View {
    var body: some View {
        VStack{
            
            ScrollView{
                HStack{
                    
                    Text("Fetuccini")
                        .font(.largeTitle)
                        .bold()
                    Spacer()
                }
                .padding(24)
                HStack{
                    Image("fetuccini")
                        .resizable()
                        .mask(RoundedRectangle(cornerRadius: 30, style: .continuous))
                        .frame(width: 350, height: 250)
                        .shadow(radius: 10)
                    
                }
                
                Text("Ingredientes")
                    .font(.title2)
                    .bold()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(24)
                    
            }
            
        }
        
    }
}

#Preview {
    FetucciniView()
}
