//
//  Fetuccini.swift
//  Bonsai p1
//
//  Created by CETYS Universidad  on 10/10/23.
//

import SwiftUI

struct Fetuccini: View {
    @State var translation: CGSize = .zero
    @State var offsetY: CGFloat = 0
   
    
    var body: some View {
        VStack{
            Spacer()
            RoundedRectangle(cornerRadius: 30)
                .frame(width: 75, height: 10)
                
            FetucciniView()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(.white)
        .mask(RoundedRectangle(cornerRadius: 30, style: .continuous))
        .offset(y: translation.height )
        .gesture(
             DragGesture()
                .onChanged{ value in
                    translation = value.translation
                }
                .onEnded{value in
                    withAnimation(.interactiveSpring(response: 0.5, dampingFraction: 0.7)){
                        let snap = translation.height + offsetY
                        
                        if snap > 100{
                          
                        }
                        translation = .zero
                    }
                }
                    
                
        )
        .ignoresSafeArea(edges: .bottom)
        
        
    }
}

#Preview {
    Fetuccini()
}
