//
//  profileView.swift
//  Bonsai p1
//
//  Created by CETYS Universidad  on 05/10/23.
//

import SwiftUI

struct HomeView: View {
    
    @State var showView: Bool = false
    var body: some View {
        ZStack{
            VStack{
                Text("Recetas")
                    .font(.largeTitle)
                    .bold()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(20)
                ScrollView{
                    Text("Saludable")
                        .font((.title))
                        .bold()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(20)
                    ScrollView(.horizontal){
                        
                        HStack{
                            Spacer()
                            Image("fetuccini")
                                .resizable()
                                .frame(width: 250, height: 150)
                                .mask(RoundedRectangle(cornerRadius: 25.0, style: .continuous))
                                .onTapGesture {
                                    showView.toggle()
                                }
                                .fullScreenCover(isPresented: $showView, content: {
                                    Fetuccini()
                                })
                                
                             
                            RoundedRectangle(cornerRadius: 25.0, style: .continuous)
                                .frame(width: 250, height: 150)
                            RoundedRectangle(cornerRadius: 25.0, style: .continuous)
                                .frame(width: 250, height: 150)
                                
                        }
                    }
                    
                    Text("Proteínico")
                        .font((.title))
                        .bold()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(20)
                    ScrollView(.horizontal){
                        HStack{
                            Spacer()
                            RoundedRectangle(cornerRadius: 25.0, style: .continuous)
                                .frame(width: 250, height: 150)
                              
                            RoundedRectangle(cornerRadius: 25.0, style: .continuous)
                                .frame(width: 250, height: 150)
                            RoundedRectangle(cornerRadius: 25.0, style: .continuous)
                                .frame(width: 250, height: 150)
                                
                        }
                    }
                    Text("Vegana")
                        .font((.title))
                        .bold()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(20)
                    ScrollView(.horizontal){
                        HStack{
                            Spacer()
                            RoundedRectangle(cornerRadius: 25.0, style: .continuous)
                                .frame(width: 250, height: 150)
                                
                            RoundedRectangle(cornerRadius: 25.0, style: .continuous)
                                .frame(width: 250, height: 150)
                            RoundedRectangle(cornerRadius: 25.0, style: .continuous)
                                .frame(width: 250, height: 150)
                                
                        }
                    }
                }
            }
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
