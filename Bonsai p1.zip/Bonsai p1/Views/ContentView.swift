//
//  ContentView.swift
//  Bonsai p1
//
//  Created by CETYS Universidad  on 10/10/23.
//

import SwiftUI

struct ContentView: View {
    
    
    var body: some View {
        ZStack{
            HomeView()
            
            
        }
    }
}

#Preview {
    ContentView()
}
