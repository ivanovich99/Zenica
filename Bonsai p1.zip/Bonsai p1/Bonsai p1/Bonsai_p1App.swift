//
//  Bonsai_p1App.swift
//  Bonsai p1
//
//  Created by CETYS Universidad  on 03/10/23.
//

import SwiftUI

@main
struct Bonsai_p1App: App {
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                
        }
    }
}
